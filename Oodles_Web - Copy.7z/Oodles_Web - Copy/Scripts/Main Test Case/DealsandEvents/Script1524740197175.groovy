import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.callTestCase(findTestCase('Common Test Case/Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Sidebar_Menu/span_Deals  Events'))

WebUI.click(findTestObject('Deals_and_Events/i_icon-pencil'))

WebUI.click(findTestObject('Deals_and_Events/button_cancel'))

WebUI.verifyElementPresent(findTestObject('Deals_and_Events/title_Events'), 0)

WebUI.selectOptionByValue(findTestObject('Deals_and_Events/dd_status'), 'A', false)

WebUI.click(findTestObject('Deals_and_Events/button_Submit'))

WebUI.waitForPageLoad(0)

WebUI.waitForElementVisible(findTestObject('Deals_and_Events/i_icon-pencil'), 0)

WebUI.click(findTestObject('Deals_and_Events/i_icon-pencil'))

WebUI.setText(findTestObject('Deals_and_Events/Edit_Deal/textarea_scorcher_text'), 'Test')

WebUI.setText(findTestObject('Deals_and_Events/Edit_Deal/textarea_hotter_text'), 'Test')

WebUI.setText(findTestObject('Deals_and_Events/Edit_Deal/textarea_deal_text'), 'Test')

WebUI.click(findTestObject('Deals_and_Events/Edit_Deal/button_Submit (1)'))

WebUI.selectOptionByValue(findTestObject('Deals_and_Events/select_Select offer type'), 'E', true)

WebUI.click(findTestObject('Deals_and_Events/button_Submit'))

WebUI.waitForPageLoad(0)

WebUI.waitForElementVisible(findTestObject('Deals_and_Events/i_icon-pencil'), 0)

WebUI.click(findTestObject('Deals_and_Events/i_icon-pencil'))

WebUI.setText(findTestObject('Deals_and_Events/Edit_Deal/textarea_scorcher_text'), 'Test_Edit')

WebUI.setText(findTestObject('Deals_and_Events/Edit_Deal/textarea_hotter_text'), 'Test_Edit')

WebUI.setText(findTestObject('Deals_and_Events/Edit_Deal/textarea_deal_text'), 'Test_Edit')

WebUI.click(findTestObject('Deals_and_Events/Edit_Deal/button_Submit (1)'))

WebUI.click(findTestObject('Deals_and_Events/span_Saurabh parekh'))

WebUI.click(findTestObject('Deals_and_Events/span_Saurabh parekh'))

WebUI.click(findTestObject('Deals_and_Events/a_Log Out'))

WebUI.closeBrowser()

