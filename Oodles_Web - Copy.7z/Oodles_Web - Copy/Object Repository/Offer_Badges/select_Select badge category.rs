<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>select_Select badge category</name>
   <tag></tag>
   <elementGuidId>46836ff5-218e-4e52-9e5f-84c68b102490</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id='tab_0']/div/div[2]/form/div/div/div/select</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//select[@name = 'badge_category_id' and (text() = '
                                                                    Select badge category
                                                                                                                                           Events
                                                                                                                                           Restaurant
                                                                                                                                    ' or . = '
                                                                    Select badge category
                                                                                                                                           Events
                                                                                                                                           Restaurant
                                                                                                                                    ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>select</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>name</name>
      <type>Main</type>
      <value>badge_category_id</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                                                    Select badge category
                                                                                                                                           Events
                                                                                                                                           Restaurant
                                                                                                                                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tab_0&quot;)/div[@class=&quot;portlet light bordered&quot;]/div[@class=&quot;portlet-body form&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;form-body&quot;]/div[@class=&quot;form-group&quot;]/div[@class=&quot;col-md-4&quot;]/select[@class=&quot;form-control&quot;]</value>
   </webElementProperties>
</WebElementEntity>
