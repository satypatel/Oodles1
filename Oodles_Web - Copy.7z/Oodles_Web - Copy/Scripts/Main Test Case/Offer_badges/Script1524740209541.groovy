import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.callTestCase(findTestCase('Common Test Case/Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Sidebar_Menu/span_Manage Offer Badges'))

WebUI.verifyElementText(findTestObject('Offer_Badges/title_manage_offer'), 'Manage Offer Badges')

WebUI.click(findTestObject('Offer_Badges/a_Create Offer Badge'))

not_run: WebUI.verifyElementText(findTestObject('Offer_Badges/title_add_offer'), 'Add offer Badge')

WebUI.click(findTestObject('Offer_Badges/button_Submit'))

WebUI.verifyElementText(findTestObject('Offer_Badges/error_Badge_Category'), 'Please select badge category')

WebUI.verifyElementText(findTestObject('Offer_Badges/error_Select_Tier'), 'Please select tier')

WebUI.verifyElementText(findTestObject('Offer_Badges/error_Upload_Image'), 'Please upload badge image')

WebUI.verifyElementText(findTestObject('Offer_Badges/error_Badge_Text'), 'Please enter badge text')

WebUI.selectOptionByValue(findTestObject('Offer_Badges/select_Select badge category'), '2', true)

WebUI.selectOptionByValue(findTestObject('Offer_Badges/select_Select tier'), '1', true)

WebUI.uploadFile(findTestObject('Offer_Badges/button_Upload'), 'C:\\\\Users\\\\Sanket.Patel\\\\Desktop\\\\Oodles_Web\\\\test_image.png')

WebUI.setText(findTestObject('Offer_Badges/textarea_badge_text'), 'Test')

WebUI.click(findTestObject('Offer_Badges/button_Submit'))

WebUI.callTestCase(findTestCase('Common Test Case/Log_out'), [:], FailureHandling.STOP_ON_FAILURE)

