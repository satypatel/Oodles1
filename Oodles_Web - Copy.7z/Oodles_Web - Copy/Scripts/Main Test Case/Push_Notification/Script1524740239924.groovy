import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.checkpoint.CheckpointFactory as CheckpointFactory
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as MobileBuiltInKeywords
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testcase.TestCaseFactory as TestCaseFactory
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testdata.TestDataFactory as TestDataFactory
import com.kms.katalon.core.testobject.ObjectRepository as ObjectRepository
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WSBuiltInKeywords
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUiBuiltInKeywords
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import internal.GlobalVariable as GlobalVariable
import org.openqa.selenium.Keys as Keys

WebUI.callTestCase(findTestCase('Common Test Case/Login'), [:], FailureHandling.STOP_ON_FAILURE)

WebUI.click(findTestObject('Sidebar_Menu/span_Manage Push Notification'))

WebUI.verifyElementPresent(findTestObject('notification/title_send_notification'), 0)

WebUI.verifyElementText(findTestObject('notification/label_choose_campus'), 'Choose Campus')

WebUI.verifyElementText(findTestObject('notification/label_choose_deal'), 'Choose Deal')

WebUI.verifyElementText(findTestObject('notification/label_message'), 'Message')

WebUI.click(findTestObject('notification/button_Send'))

WebUI.verifyElementText(findTestObject('notification/text_Campus_error_msg'), 'Please select campus')

WebUI.verifyElementText(findTestObject('notification/text_Message_error'), 'Please enter message')

WebUI.click(findTestObject('notification/button_Cancel'))

WebUI.verifyElementPresent(findTestObject('Dashboard/title_text_dashboard'), 0)

WebUI.click(findTestObject('Sidebar_Menu/span_Manage Push Notification'))

WebUI.selectOptionByValue(findTestObject('notification/select_Select campus'), '2', true)

WebUI.selectOptionByValue(findTestObject('Page_Oodles - Send Notifications/select_Select Deal1st novAcroF'), '150', true)

WebUI.setText(findTestObject('notification/textarea_message'), 'test')

WebUI.click(findTestObject('notification/button_Send'))

WebUI.verifyElementText(findTestObject('notification/text_success_msg'), 'Notification sent successfully')

WebUI.callTestCase(findTestCase('Common Test Case/Log_out'), [:], FailureHandling.STOP_ON_FAILURE)

