<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Submit (1)</name>
   <tag></tag>
   <elementGuidId>e19ed7d5-c432-42cd-b944-0ba01506b582</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//button[@type = 'submit' and (text() = 'Submit' or . = 'Submit')]</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>/html/body/div[3]/div[2]/div/div[2]/div/div/div/div/div/div[2]/form/div[2]/div/div/button[1]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn blue</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Submit</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tab_0&quot;)/div[@class=&quot;portlet light bordered&quot;]/div[@class=&quot;portlet-body form&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;form-actions&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-offset-3 col-md-4&quot;]/button[@class=&quot;btn blue&quot;]</value>
   </webElementProperties>
</WebElementEntity>
