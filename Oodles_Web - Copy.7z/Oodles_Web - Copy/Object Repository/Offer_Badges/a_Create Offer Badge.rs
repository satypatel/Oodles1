<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Create Offer Badge</name>
   <tag></tag>
   <elementGuidId>d4eb7887-8883-4c85-8782-dc5c55330e99</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>/html/body/div[3]/div[2]/div/div[2]/div/div/div[1]/div[2]/div/a/i</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//a[@href = 'http://172.16.3.24:35/admin/offerbadges/create' and (text() = 'Create Offer Badge' or . = 'Create Offer Badge')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn uppercase red</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://172.16.3.24:35/admin/offerbadges/create</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Create Offer Badge</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;page-header-fixed page-sidebar-closed-hide-logo page-content-white&quot;]/div[@class=&quot;page-container&quot;]/div[@class=&quot;page-content-wrapper&quot;]/div[@class=&quot;page-content&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;portlet light bordered&quot;]/div[@class=&quot;portlet-title&quot;]/div[@class=&quot;actions&quot;]/div[@class=&quot;btn-group&quot;]/a[@class=&quot;btn uppercase red&quot;]</value>
   </webElementProperties>
</WebElementEntity>
